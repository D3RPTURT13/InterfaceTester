# InterfaceTester
This repo contains the tester class for the interface program.

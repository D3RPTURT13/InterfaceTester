
public abstract class Animal {
	protected int legs;
	public String eat;
	public String walk;
	public Animal(int legs) {
		this.legs = legs;
	}
public abstract String eat();
public String  walk() {
	return "This animal walks on" + legs + "/n";
}

}

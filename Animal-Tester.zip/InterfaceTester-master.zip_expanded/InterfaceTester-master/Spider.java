
public class Spider extends Animal {
	public Spider(int legs) {
super(legs);
this.legs = legs;
	}
	public int getSpiderLegs() {
		return legs;
	}
	public void setSpiderLegs(int legs) {
		legs = 8;
	}
	public String eat() {
		return "Insects(meat)";
	}
}

public class Cat extends Pet{
public class Cat implements Pet{
		public String Fluffy;
		public class Cat extends Animal{
			public Cat(int legs, String Fluffy) {
				super(legs);
				this.legs = legs;
				this.Fluffy = Fluffy;
			}
			public int getCatLegs() {
				return legs;
			}
			public void setCatLegs(int legs) {
				legs = 4;
			}
	public String getFluffyName() {
		return Fluffy;
	}

	public void setFluffyName(String Fluffy) {
		this.Fluffy = Fluffy;	
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;	
	}
	public void play() {
		return "This pet is playing with a scratching pole";
			}
	public String eat() {
		return "Cat food and Table scraps";
			}
		}
	}
}


public class Fish extends Pet{
public class Fish implements Pet{
		public String Piscene;
		public class Fish extends Animal{
			public Cat(int legs, String Scaly) {
				super(legs);
				this.legs = legs;
				this.Scaly = Scaly;
			}
			public int getFishLegs() {
				return legs;
			}
			public void setFishLegs(int legs) {
				legs = 0;
			}
	public String getPisceneName() {
		return Piscene;
	}

	public void setPisceneName(String Piscene) {
		this.Piscene = Piscene;	
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = "Piscene";	
	}
	public void play() {
		return "This pet plays with it's reflection";
			}
	public String eat() {
		return "Fish food and dried baby shrimp";
			}
		}
	}
}